#!/usr/bin/env python3
""" Several users reading a calendar, but only a few users updating it """

import threading

WEEKDAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
today = 0
marker = threading.Lock()

def calendar_reader(id_number):
    global today
    name = 'Reader-' + str(id_number)
    while today < len(WEEKDAYS)-1:
        marker.acquire()
        print(name, 'sees that today is', WEEKDAYS[today])
        marker.release()

def calendar_writer(id_number):
    global today
    name = 'Writer-' + str(id_number)
    while today < len(WEEKDAYS)-1:
        marker.acquire()
        today = (today + 1) % 7
        print(name, 'updated date to ', WEEKDAYS[today])
        marker.release()

if __name__ == '__main__':
    # create ten reader threads
    for i in range(10):
        threading.Thread(target=calendar_reader, args=(i,)).start()
    # ...but only two writer threads
    for i in range(2):
        threading.Thread(target=calendar_writer, args=(i,)).start()
